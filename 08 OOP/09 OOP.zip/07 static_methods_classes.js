// class definition
class Student {
  constructor(sName, sAge) {
    this.sName = sName;
    this.sAge = sAge;
  }

  calcBirthYear() {
    return 2022 - this.sAge;
  }

  //   static method definition
  static getNumberOfProperties = function () {
    const numProps = Student.length;
    return numProps;
  };
}

const sreekar = new Student("Sreekar", 13);
console.log(sreekar.calcBirthYear());

// static methid can be accessed only on class
console.log(Student.getNumberOfProperties());

// not available for individual objects
// console.log(sreekar.getNumberOfProperties());

console.log(sreekar);
